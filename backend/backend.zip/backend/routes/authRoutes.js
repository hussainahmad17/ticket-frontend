import express from "express"
import { createUserByAdmin, loginUser } from "../controllers/authController.js";
import { authorizeRoles } from "../middleware/roleMiddleware.js";
import { protect } from "../middleware/authMiddleware.js";
const router = express.Router();


router.post("/login",loginUser)
router.post("/create",protect,authorizeRoles("admin"),createUserByAdmin)
export default router